IoT-LAB Main Repository
=======================

This repository contains common IoT-LAB resources, such as
experiments management tools, deployment tools, dev. env. setup.

Overall documentation is available at https://github.com/iot-lab/iot-lab/wiki

To perform the initial setup of your development environment, run ``make``.
